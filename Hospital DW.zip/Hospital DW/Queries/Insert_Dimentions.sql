-- DimWard
select WardId, WardName, Description
from [SA_Ward]

-- DimCondition
SELECT DISTINCT CurrentCondition as DimConditionDesc,
    (CASE 
        WHEN CurrentCondition = 'good' THEN 3
        WHEN CurrentCondition = 'fair' THEN 2
        WHEN CurrentCondition = 'poor' THEN 1
        WHEN CurrentCondition = 'dead' THEN 0
        ELSE NULL  -- Handle unexpected values
    END) as DimConditionVal
FROM SA_Treatment;

-- DimSpeciality
SELECT SpecialityId, SpecialityName, Description
FROM SA_Speciality

-- DimDoctor
SELECT DoctorId, FirstName, LastName, Gender, BirthDate, Email, Phone, StreetAdress, City, State
FROM SA_Doctor;

-- DimNurse
SELECT NurseId, FirstName, LastName, Gender, BirthDate, Email, Phone, StreetAddress, City, State, Zipcode, DueWorksPerMonth
FROM SA_Nurse;

-- DimPharmacy
SELECT PharmacyId, StoreNName, StreetAddress, City, State, Zipcode, Phone, LeadPharmacist, Email
FROM SA_Pharmacy;

-- DimSupervisor
SELECT SupervisorId, FirstName, LastName, Gender, BirthDate, Email, Phone, StreetAdress, City, State
FROM SA_Supervisor;

-- DimMedicine
SELECT MedicineId, medicineName AS Name, Description, SideEffects, Form, Dosage, ManufacturerName, CAST(Price AS DECIMAL(10,2)) AS Price
FROM SA_Medicine;

-- DimPatient
SELECT 
    PatientId AS PatientCode,
    FirstName, 
    LastName, 
    Gender, 
    BirthDate, 
    Email, 
    Phone, 
    StreetAdress AS StreetAddress, 
    City, 
    State, 
    Zipcode AS ZipCode, 
    Allergies, 
    ChronicDisease, 
    OtherHealthConcerns, 
    InsuranceNumber, 
    GETDATE() AS Start_date,
    NULL AS End_date, 
    1 AS CurrentFlag 
FROM 
    SA_Patient;

--DimTreatment
SELECT 
    TreatmentDetailsId AS TreatmentCode,
    TreatmentName,
    Description AS TrearmentDesc,
    Price,
    GETDATE() AS Start_date,
    NULL AS End_date,  
    CAST(1 AS BIT) AS CurrentFlag
FROM 
    SA_TreatmentDetails;

-- DimInsurance
SELECT 
    InsuranceNumber AS InsuranceCode,
    InsuranceNetwork,
    PolicyName,
    Deductible,
    Co_pay,
    GETDATE() AS Start_date,
    NULL AS End_date,
    CAST(1 AS BIT) AS CurrentFlag
FROM 
    SA_InsurancePolicy;

-- DimDate
delete [hospital_datawarehouse].[dbo].[DimDate]
DECLARE @StartDate DATE = '2023-06-30';
DECLARE @EndDate DATE = '2024-06-28';
CREATE TABLE #DateGenerator (
    GeneratedDate DATE PRIMARY KEY
);
DECLARE @CurrentDate DATE = @StartDate;
WHILE @CurrentDate <= @EndDate
BEGIN
    INSERT INTO #DateGenerator (GeneratedDate)
    VALUES (@CurrentDate);
    SET @CurrentDate = DATEADD(DAY, 1, @CurrentDate);
END
INSERT INTO [hospital_datawarehouse].[dbo].[DimDate] (DateKey, [Year], Season, [Month], DayOfWeek)
SELECT
    GeneratedDate AS DateKey,
    YEAR(GeneratedDate) AS [Year],
    CASE 
        WHEN MONTH(GeneratedDate) IN (12, 1, 2) THEN 'Winter'
        WHEN MONTH(GeneratedDate) IN (3, 4, 5) THEN 'Spring'
        WHEN MONTH(GeneratedDate) IN (6, 7, 8) THEN 'Summer'
        WHEN MONTH(GeneratedDate) IN (9, 10, 11) THEN 'Autumn'
    END AS Season,
    DATENAME(MONTH, GeneratedDate) AS [Month],
    DATENAME(WEEKDAY, GeneratedDate) AS DayOfWeek
FROM #DateGenerator;

-- DimTime
DECLARE @Hour INT = 0;
DECLARE @Minute INT = 0;
DECLARE @Second INT = 0;
WHILE @Hour < 24
BEGIN
    SET @Minute = 0;
    WHILE @Minute < 60
    BEGIN
        SET @Second = 0;
        WHILE @Second < 60
        BEGIN
            INSERT INTO [hospital_datawarehouse].[dbo].[DimTime] (TimeKey, Hour, Minute, Second)
            VALUES (
                CONVERT(TIME, CONVERT(VARCHAR(2), @Hour) + ':' + CONVERT(VARCHAR(2), @Minute) + ':' + CONVERT(VARCHAR(2), @Second)),
                @Hour,
                @Minute,
                @Second
            );
            SET @Second = @Second + 1;
        END
        SET @Minute = @Minute + 1;
    END
    SET @Hour = @Hour + 1;
END