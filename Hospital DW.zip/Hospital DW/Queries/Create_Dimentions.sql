CREATE TABLE DimWard (
    WardId INTEGER PRIMARY KEY,
    WardName VARCHAR(50),
    Description VARCHAR(100)
);
select * from DimWard

drop table DimCondition
CREATE TABLE DimCondition (
    ConditionId INTEGER PRIMARY KEY IDENTITY(1, 1),
    ConditionDesc VARCHAR(100),
    ConditionVal VARCHAR(100)
);
select * from DimCondition

drop table DimSpeciality
CREATE TABLE DimSpeciality (
    SpecialityId INTEGER PRIMARY KEY,
    SpecialityName VARCHAR(50),
    Description VARCHAR(200)
);
select * from DimSpeciality

drop table DimPharmacy
CREATE TABLE DimPharmacy (
    PharmacyId INTEGER PRIMARY KEY NOT NULL,
    StoreName VARCHAR(50),
    StreetAddress VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
    ZipCode VARCHAR(50),
    Phone VARCHAR(100),
    LeadPharmacist VARCHAR(50),
    Email VARCHAR(100)
);
select * from DimPharmacy

truncate table DimPatient
CREATE TABLE DimPatient (
    PatientId INTEGER IDENTITY(1,1) PRIMARY KEY,
    PatientCode INTEGER NOT NULL,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Gender INTEGER,
    BirthDate DATE,
    Email VARCHAR(100),
    Phone VARCHAR(100),
    StreetAddress VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
    ZipCode VARCHAR(50),
    Allergies CHAR(100),
    ChronicDisease CHAR(100),
    OtherHealthConcerns CHAR(100),
    InsuranceNumber INTEGER NOT NULL,
    Start_date DATE,
    End_date DATE,
    CurrentFlag BIT
);
select * from DimPatient

update [hospital_staging_area].[dbo].[SA_Patient]
set OtherHealthConcerns = 'cancer2'
where PatientId = 1

select * from [hospital_staging_area].[dbo].[SA_Patient] where PatientId = 1
select * from DimPatient where PatientCode = 1

CREATE TABLE DimDoctor (
    DoctorId INTEGER PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Gender INTEGER,
    BirthDate DATE,
    Email VARCHAR(100),
    Phone VARCHAR(100),
    StreetAddress VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
);
select * from DimDoctor

CREATE TABLE DimSupervisor (
    SupervisorId INTEGER PRIMARY KEY NOT NULL,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Gender INTEGER,
    BirthDate DATE,
    Email VARCHAR(100),
    Phone VARCHAR(100),
    StreetAddress VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
);
select * from DimSupervisor

CREATE TABLE DimNurse (
    NurseId INTEGER PRIMARY KEY NOT NULL,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Gender INTEGER, 
    BirthDate DATE,
    Email VARCHAR(100),
    Phone VARCHAR(100),
    StreetAddress VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
    ZipCode VARCHAR(50),
    DueWorkHoursPerMonth INTEGER NOT NULL
);
select * from DimNurse

CREATE TABLE DimMedicine (
    MedicineId INTEGER PRIMARY KEY NOT NULL,
    Name VARCHAR(50),
    Description VARCHAR(100),
    SideEffects VARCHAR(100),
    Form VARCHAR(50),
    Dosage VARCHAR(50),
    ManufacturerName VARCHAR(100),
    Price DECIMAL(10,2)
);
select * from DimMedicine

drop table DimInsurance
CREATE TABLE DimInsurance (
    InsuranceId INTEGER IDENTITY(1,1) PRIMARY KEY,
    InsuranceCode  INTEGER,     
    InsuranceNetwork VARCHAR(100),
    PolicyName VARCHAR(100),
    Deductible decimal(10,2),
    Co_pay FLOAT NOT NULL,
    Start_date DATE,
    End_date DATE,
    CurrentFlag BIT
);
select * from DimInsurance

update [hospital_staging_area].[dbo].[SA_InsurancePolicy]
set Deductible = 12.00
where InsuranceNumber = 1

select * from [hospital_staging_area].[dbo].SA_InsurancePolicy where InsuranceNumber = 1
select * from DimInsurance where InsuranceCode = 1

drop table DimTreatment
CREATE TABLE DimTreatment (
    TreatmentId INTEGER IDENTITY(1,1) PRIMARY KEY,
    TreatmentCode INTEGER,
    TreatmentName VARCHAR(50),
    TrearmentDesc VARCHAR(100),
    Price DECIMAL(10,2),
    Start_date DATE,
    End_date DATE,
    CurrentFlag BIT
);

select * from DimTreatment
select * from [hospital_staging_area].[dbo].SA_TreatmentDetails

drop table DimDate
CREATE TABLE DimDate (
    DateKey DATE PRIMARY KEY,
    [Year] INTEGER,
    Season VARCHAR(20),
    [Month] VARCHAR(20),
    [DayOfWeek] VARCHAR(20),
);

drop table DimTime
CREATE TABLE DimTime (
    TimeKey TIME PRIMARY KEY,
    Hour INTEGER,
    Minute INTEGER,
    Second INTEGER
);