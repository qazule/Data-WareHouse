CREATE TABLE Ward
(
WardId              integer PRIMARY KEY NOT NULL,
WardName            CHAR(30),
Description         CHAR(100)
);
CREATE TABLE Room
(
RoomId              integer PRIMARY KEY NOT NULL,
WardId              integer,
RoomNumber          VARCHAR(100),

FOREIGN KEY(WardId) REFERENCES Ward(WardId)
);

CREATE TABLE Pharmacy
(
PharmacyId          integer PRIMARY KEY NOT NULL,
StoreNName          VARCHAR(10),
StreetAddress       VARCHAR(25),
City                VARCHAR(20),
State               VARCHAR(20),
Zipcode             VARCHAR(20),
Phone               VARCHAR(20),
LeadPharmacist      VARCHAR(20),
Email               VARCHAR(30)
);

CREATE TABLE InsurancePolicy
(
InsuranceNumber       integer PRIMARY KEY NOT NULL,
InsuranceNetwork      CHAR(30),
PolicyName            CHAR(30),
Description           VARCHAR(25),
Deductible            decimal(10,2),
Co_pay                float NOT NULL
);

CREATE TABLE Patient
(
PatientId           integer PRIMARY KEY NOT NULL,
RoomId              integer NOT NULL,
FirstName           VARCHAR(20),
LastName            VARCHAR(20),
Gender				VARCHAR(20),
BirthDate			Date,
Email               VARCHAR(50),
Phone               VARCHAR(20),
StreetAdress        VARCHAR(20),
City                VARCHAR(20),
State               VARCHAR(20),
Zipcode             VARCHAR(20),
Allergies           CHAR(30),
ChronicDisease      CHAR(30),
OtherHealthConcerns CHAR(30),

InsuranceNumber       integer NOT NULL,

FOREIGN KEY(InsuranceNumber) REFERENCES InsurancePolicy(InsuranceNumber),
FOREIGN KEY(RoomId) REFERENCES Room(RoomId)
);
CREATE TABLE TreatmentDetails
(
TreatmentDetailsId     integer PRIMARY KEY ,
TreatmentName          VARCHAR(25),
Description            CHAR(100),
Price                  decimal(10,2)
);

ALTER TABLE Supervisor
ALTER COLUMN StreetAdress VARCHAR(100);

CREATE TABLE Supervisor
(
SupervisorId		integer PRIMARY KEY NOT NULL,
FirstName			VARCHAR(50),
LastName			varchar(50),
Gender				varchar(20),
BirthDate			Date,
Email               VARCHAR(100),
Phone               VARCHAR(20),
StreetAdress        VARCHAR(100),
City                VARCHAR(20),
State               VARCHAR(20),
);

CREATE TABLE Speciality
(
SpecialityId        integer PRIMARY KEY NOT NULL,
SpecialityName      VARCHAR(20),
Description         VARCHAR(200)
);

ALTER TABLE Speciality
ALTER COLUMN SpecialityName VARCHAR(50);

ALTER TABLE Doctor
ALTER COLUMN Email VARCHAR(50);

-- Add SupervisorId column
ALTER TABLE Doctor
ADD SupervisorId INTEGER NOT NULL;

-- Add foreign key constraint
ALTER TABLE Doctor
ADD CONSTRAINT FK_Doctor_Supervisor
FOREIGN KEY (SupervisorId)
REFERENCES Supervisor(SupervisorId);

CREATE TABLE Doctor
(
DoctorId            integer PRIMARY KEY NOT NULL,
SpecialityId		integer NOT NULL,
FirstName           VARCHAR(20),
LastName            VARCHAR(20),
Gender				VARCHAR(20),
BirthDate			Date,
Email               VARCHAR(50),
Phone               VARCHAR(20),
StreetAdress        VARCHAR(20),
City                VARCHAR(20),
State               VARCHAR(20),
SupervisorId		integer NOT NULL,

FOREIGN KEY(SPecialityId) REFERENCES Speciality(SpecialityId),
FOREIGN KEY(SupervisorId) REFERENCES Supervisor(SupervisorId),
);


CREATE TABLE Treatment
(
TreatmentId           integer PRIMARY KEY NOT NULL,
PatientId             integer,
DoctorId			  integer,
TreatmentDetailsId    integer,
CurrentCondition      VARCHAR(100),
TreatmentDate         datetime,					

FOREIGN KEY(PatientId) REFERENCES Patient(PatientId),
FOREIGN KEY(TreatmentDetailsId) REFERENCES TreatmentDetails(TreatmentDetailsId),
FOREIGN KEY(DoctorId) REFERENCES Doctor(DoctorId)
);

CREATE TABLE Payment
(
PaymentNumber        integer PRIMARY KEY NOT NULL,
PatientId            integer,
TreatmentId          integer,
TotalAmountDue       decimal(10,2),
DueDate              datetime,
AmountPaid           decimal(10,2),
CurrentBalance       decimal(10,2),

FOREIGN KEY(TreatmentId) REFERENCES Treatment(TreatmentId),
FOREIGN KEY(PatientId)   REFERENCES Patient(PatientId)
);

CREATE TABLE InsurancePayment
(
PaymentNumber         integer  NOT NULL,
InsuranceNumber       integer NOT NULL,
AppliedDeductible     decimal(10,2),

PRIMARY KEY (PaymentNumber, InsuranceNumber),
FOREIGN KEY(InsuranceNumber) REFERENCES InsurancePolicy(InsuranceNumber),
FOREIGN KEY(PaymentNumber) REFERENCES Payment(PaymentNumber)
);

CREATE TABLE Medicine
(
MedicineId			integer PRIMARY KEY NOT NULL,
medicineName		varchar(30),
Description			varchar(100),
SideEffects			varchar(50),
expiryDate			Date,
Form				varchar(50),
Dosage				varchar(50),
ManufacturerName	varchar(100),
Price				float,	
);

CREATE TABLE Perscription
(
PerscriptionId			integer PRIMARY KEY NOT NULL,
MedicineId				integer,
DoctorId				integer,
Quantity				integer,
AmountPaidByPatient		integer,

FOREIGN KEY(MedicineId) REFERENCES Medicine(MedicineId),
FOREIGN KEY(DoctorId) REFERENCES Doctor(DoctorId)
);

CREATE TABLE PerscriptionHistory
(
PatientId           integer NOT NULL,
PharmacyId			integer,
PerscriptionId      integer,
DatePerscribed      datetime,
UsageInstruction    VARCHAR(20),

FOREIGN KEY(PharmacyId)      REFERENCES Pharmacy(PharmacyId),
FOREIGN KEY(PatientId)      REFERENCES Patient(PatientId),
FOREIGN KEY(PerscriptionId) REFERENCES Perscription(PerscriptionId)
);

CREATE TABLE Nurse
(
NurseId             integer PRIMARY KEY NOT NULL,
FirstName           VARCHAR(20),
LastName            VARCHAR(20),
Gender				VARCHAR(20),
BirthDate			Date,
Email               VARCHAR(20),
Phone               VARCHAR(20),
StreetAddress       VARCHAR(20),
City                VARCHAR(20),
State               VARCHAR(20),
Zipcode             VARCHAR(20),
DueWorksPerMonth	integer NOt NULL,
);

CREATE TABLE NurseWard
(
WardAssignmentId    integer PRIMARY KEY NOT NULL,
NurseId             integer,
WardId              integer,
Shift_start_time    datetime,
Shift_end_time      datetime,


FOREIGN KEY(NurseId) REFERENCES Nurse(NurseId),
FOREIGN KEY(WardId) REFERENCES Ward(WardId)
);

CREATE TABLE DoctorPatient
(
DoctorId            integer NOT NULL,
PatientId           integer NOT NULL,
AptDate             datetime,

PRIMARY KEY (DoctorId, PatientId, AptDate),
FOREIGN KEY(DoctorId)  REFERENCES Doctor(DoctorId),
FOREIGN KEY(PatientId) REFERENCES Patient(PatientId),
);

CREATE TABLE Doctor_Speciality
(
SpecialityId       integer NOT NULL,
DoctorId           integer not null ,

PRIMARY KEY (SpecialityId, DoctorId),
FOREIGN KEY(SpecialityId) REFERENCES Speciality(SpecialityId),
FOREIGN KEY(DoctorId) REFERENCES Doctor(DoctorID)
);