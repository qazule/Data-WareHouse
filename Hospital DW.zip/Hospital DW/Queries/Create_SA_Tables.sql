DROP TABLE SA_Ward
delete SA_Ward
-- VARCHAR WardName and Description and WardName 50
CREATE TABLE SA_Ward
(
WardId              integer PRIMARY KEY NOT NULL,
WardName            VARCHAR(50),
Description         VARCHAR(100)
);

select * from SA_Ward

CREATE TABLE SA_Room
(
RoomId              integer PRIMARY KEY NOT NULL,
WardId              integer,
RoomNumber          VARCHAR(100),
FOREIGN KEY(WardId) REFERENCES SA_Ward(WardId)
);

select * from SA_Room

-- 50 100 50 ...
CREATE TABLE SA_Pharmacy
(
PharmacyId          integer PRIMARY KEY NOT NULL,
StoreNName          VARCHAR(50),
StreetAddress       VARCHAR(100),
City                VARCHAR(50),
State               VARCHAR(50),
Zipcode             VARCHAR(50),
Phone               VARCHAR(50),
LeadPharmacist      VARCHAR(50),
Email               VARCHAR(100)
);

select * from SA_Pharmacy

-- varchar and 100
CREATE TABLE SA_InsurancePolicy
(
InsuranceNumber       integer PRIMARY KEY NOT NULL,
InsuranceNetwork      VARCHAR(100),
PolicyName            VARCHAR(100),
Description           VARCHAR(100),
Deductible            decimal(10,2),
Co_pay                float NOT NULL
);

select * from SA_InsurancePolicy

-- varchar and 100 and gender integer
ALTER TABLE SA_Patient
ALTER COLUMN Phone VARCHAR(100);

delete SA_Patient
CREATE TABLE SA_Patient
(
PatientId           integer PRIMARY KEY NOT NULL,
RoomId              integer NOT NULL,
FirstName           VARCHAR(50),
LastName            VARCHAR(50),
Gender				integer,
BirthDate			Date,
Email               VARCHAR(100),
Phone               VARCHAR(100),
StreetAdress        VARCHAR(100),
City                VARCHAR(50),
State               VARCHAR(50),
Zipcode             VARCHAR(50),
Allergies           VARCHAR(100),
ChronicDisease      VARCHAR(100),
OtherHealthConcerns VARCHAR(100),
InsuranceNumber       integer NOT NULL,
FOREIGN KEY(InsuranceNumber) REFERENCES SA_InsurancePolicy(InsuranceNumber),
FOREIGN KEY(RoomId) REFERENCES SA_Room(RoomId)
);

SELECT * FROM SA_Patient

-- varchar and 50 and 100
CREATE TABLE SA_TreatmentDetails
(
TreatmentDetailsId     integer PRIMARY KEY ,
TreatmentName          VARCHAR(50),
Description            VARCHAR(100),
Price                  decimal(10,2)
);

select * from SA_TreatmentDetails

ALTER TABLE Supervisor
ALTER COLUMN StreetAdress VARCHAR(100);

delete SA_Supervisor
-- gender integer and 50 and 100
CREATE TABLE SA_Supervisor
(
SupervisorId		integer PRIMARY KEY NOT NULL,
FirstName			VARCHAR(50),
LastName			varchar(50),
Gender				integer,
BirthDate			Date,
Email               VARCHAR(100),
Phone               VARCHAR(100),
StreetAdress        VARCHAR(100),
City                VARCHAR(50),
State               VARCHAR(50),
);

ALTER TABLE SA_Supervisor
ALTER COLUMN Phone VARCHAR(100);

select * from SA_Supervisor

CREATE TABLE SA_Speciality
(
SpecialityId        integer PRIMARY KEY NOT NULL,
SpecialityName      VARCHAR(50),
Description         VARCHAR(200)
);

ALTER TABLE Speciality
ALTER COLUMN SpecialityName VARCHAR(50);

select * from SA_Speciality

ALTER TABLE Doctor
ALTER COLUMN Email VARCHAR(50);

-- Add SupervisorId column
ALTER TABLE Doctor
ADD SupervisorId INTEGER NOT NULL;

-- Add foreign key constraint
ALTER TABLE Doctor
ADD CONSTRAINT FK_Doctor_Supervisor
FOREIGN KEY (SupervisorId)
REFERENCES Supervisor(SupervisorId);

delete SA_Doctor
-- gender integer and 100 and 50
CREATE TABLE SA_Doctor
(
DoctorId            integer PRIMARY KEY NOT NULL,
SpecialityId		integer NOT NULL,
FirstName           VARCHAR(50),
LastName            VARCHAR(50),
Gender				integer,
BirthDate			Date,
Email               VARCHAR(100),
Phone               VARCHAR(100),
StreetAdress        VARCHAR(100),
City                VARCHAR(50),
State               VARCHAR(50),
SupervisorId		integer NOT NULL,
FOREIGN KEY(SPecialityId) REFERENCES SA_Speciality(SpecialityId),
FOREIGN KEY(SupervisorId) REFERENCES SA_Supervisor(SupervisorId),
);

ALTER TABLE SA_Doctor
ALTER COLUMN Phone VARCHAR(100);

select * from SA_Doctor

delete SA_Treatment

CREATE TABLE SA_Treatment
(
TreatmentId           integer PRIMARY KEY NOT NULL,
PatientId             integer,
DoctorId			  integer,
TreatmentDetailsId    integer,
CurrentCondition      VARCHAR(100),
TreatmentDate         datetime,					
FOREIGN KEY(PatientId) REFERENCES SA_Patient(PatientId),
FOREIGN KEY(TreatmentDetailsId) REFERENCES SA_TreatmentDetails(TreatmentDetailsId),
FOREIGN KEY(DoctorId) REFERENCES SA_Doctor(DoctorId)
);

select * from SA_Treatment

CREATE TABLE SA_Payment
(
PaymentNumber        integer PRIMARY KEY NOT NULL,
PatientId            integer,
TreatmentId          integer,
TotalAmountDue       decimal(10,2),
DueDate              datetime,
AmountPaid           decimal(10,2),
CurrentBalance       decimal(10,2),
FOREIGN KEY(TreatmentId) REFERENCES SA_Treatment(TreatmentId),
FOREIGN KEY(PatientId)   REFERENCES SA_Patient(PatientId)
);

select * from SA_Payment

CREATE TABLE SA_InsurancePayment
(
PaymentNumber         integer  NOT NULL,
InsuranceNumber       integer NOT NULL,
AppliedDeductible     decimal(10,2),
PRIMARY KEY (PaymentNumber, InsuranceNumber),
FOREIGN KEY(InsuranceNumber) REFERENCES SA_InsurancePolicy(InsuranceNumber),
FOREIGN KEY(PaymentNumber) REFERENCES SA_Payment(PaymentNumber)
);

select * from SA_InsurancePayment

CREATE TABLE SA_Medicine
(
MedicineId			integer PRIMARY KEY NOT NULL,
medicineName		varchar(50),
Description			varchar(100),
SideEffects			varchar(100),
expiryDate			Date,
Form				varchar(50),
Dosage				varchar(50),
ManufacturerName	varchar(100),
Price				float,	
);

select * from SA_Medicine

CREATE TABLE SA_Perscription
(
PerscriptionId			integer PRIMARY KEY NOT NULL,
MedicineId				integer,
DoctorId				integer,
Quantity				integer,
AmountPaidByPatient		integer,
FOREIGN KEY(MedicineId) REFERENCES SA_Medicine(MedicineId),
FOREIGN KEY(DoctorId) REFERENCES SA_Doctor(DoctorId)
);

select * from SA_Perscription

CREATE TABLE SA_PerscriptionHistory
(
PatientId           integer NOT NULL,
PharmacyId			integer,
PerscriptionId      integer,
DatePerscribed      datetime,
UsageInstruction    VARCHAR(100),
FOREIGN KEY(PharmacyId)      REFERENCES SA_Pharmacy(PharmacyId),
FOREIGN KEY(PatientId)      REFERENCES SA_Patient(PatientId),
FOREIGN KEY(PerscriptionId) REFERENCES SA_Perscription(PerscriptionId)
);

select * from SA_PerscriptionHistory

delete SA_Nurse
CREATE TABLE SA_Nurse
(
NurseId             integer PRIMARY KEY NOT NULL,
FirstName           VARCHAR(50),
LastName            VARCHAR(50),
Gender				integer,
BirthDate			Date,
Email               VARCHAR(100),
Phone               VARCHAR(100),
StreetAddress       VARCHAR(100),
City                VARCHAR(50),
State               VARCHAR(50),
Zipcode             VARCHAR(50),
DueWorksPerMonth	integer NOt NULL,
);

ALTER TABLE SA_Nurse
ALTER COLUMN Zipcode VARCHAR(50);

select * from SA_Nurse

CREATE TABLE SA_NurseWard
(
WardAssignmentId    integer PRIMARY KEY NOT NULL,
NurseId             integer,
WardId              integer,
Shift_start_time    datetime,
Shift_end_time      datetime,
FOREIGN KEY(NurseId) REFERENCES SA_Nurse(NurseId),
FOREIGN KEY(WardId) REFERENCES SA_Ward(WardId)
);

select * from SA_NurseWard

CREATE TABLE SA_DoctorPatient
(
DoctorId            integer NOT NULL,
PatientId           integer NOT NULL,
AptDate             datetime,
PRIMARY KEY (DoctorId, PatientId, AptDate),
FOREIGN KEY(DoctorId)  REFERENCES SA_Doctor(DoctorId),
FOREIGN KEY(PatientId) REFERENCES SA_Patient(PatientId),
);

select * from SA_DoctorPatient

CREATE TABLE SA_Doctor_Speciality
(
SpecialityId       integer NOT NULL,
DoctorId           integer not null ,
PRIMARY KEY (SpecialityId, DoctorId),
FOREIGN KEY(SpecialityId) REFERENCES SA_Speciality(SpecialityId),
FOREIGN KEY(DoctorId) REFERENCES SA_Doctor(DoctorID)
);

select * from SA_Doctor_Speciality