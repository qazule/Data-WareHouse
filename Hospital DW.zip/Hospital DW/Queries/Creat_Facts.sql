-------------------------------------------------------------------------------------------------------------------------------------
												--Perscription Mart--
-------------------------------------------------------------------------------------------------------------------------------------
-- [TempFact_TranPerscription]
CREATE TABLE [TempFact_TranPerscription] (
    [DateKey] Date,
    [TimeKey] Time,
    [PatientId] int,
    [DoctorId] int,
    [PharmacyId] int,
    [MedicineId] int,
    [AmountPaidByPatient] int,
    [Quantity] int
)
select * from [TempFact_TranPerscription]
-- TransactionFact_Prescription
IF OBJECT_ID('dbo.TransactionFact_Prescription', 'U') IS NOT NULL
    DROP TABLE dbo.TransactionFact_Prescription;
GO
CREATE TABLE TransactionFact_Prescription (
    DateKey DATE NOT NULL,
    TimeKey TIME NOT NULL,
    PatientId INT NOT NULL,
    DoctorId INT NOT NULL,
    PharmacyId INT NOT NULL,
    MedicineId INT NOT NULL,
    AmountPaidByPatient DECIMAL(10, 2) NOT NULL,
    Quantity INT NOT NULL,
    CONSTRAINT FK_TransactionFact_Prescription_PatientId FOREIGN KEY (PatientId) REFERENCES DimPatient(PatientId),
    CONSTRAINT FK_TransactionFact_Prescription_DoctorId FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId),
    CONSTRAINT FK_TransactionFact_Prescription_PharmacyId FOREIGN KEY (PharmacyId) REFERENCES DimPharmacy(PharmacyId),
    CONSTRAINT FK_TransactionFact_Prescription_MedicineId FOREIGN KEY (MedicineId) REFERENCES DimMedicine(MedicineId)
);
select * from TransactionFact_Prescription 
select * from [hospital_staging_area].[dbo].SA_PerscriptionHistory join [hospital_staging_area].[dbo].SA_Perscription
on [hospital_staging_area].[dbo].SA_Perscription.PerscriptionId = [hospital_staging_area].[dbo].SA_PerscriptionHistory.PerscriptionId
where [hospital_staging_area].[dbo].SA_PerscriptionHistory.PatientId = 700

-- TempFact_MonthlyPerscription
drop table TempFact_MonthlyPerscription
IF OBJECT_ID('dbo.TempFact_MonthlyPerscription', 'U') IS NOT NULL
    DROP TABLE dbo.TempFact_MonthlyPerscription;
CREATE TABLE dbo.TempFact_MonthlyPerscription (
    DateKey DATE NOT NULL,
    DoctorId INT NOT NULL,
    MedicineId INT NOT NULL,
    TotalMonthlyQuantity INT NOT NULL,
    TotalMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    TotalMonthlyNumberOfPatientsPrescribed INT NOT NULL,
    AverageMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MinMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MaxMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    CONSTRAINT PK_TempFact_MonthlyPerscription PRIMARY KEY (DateKey, DoctorId, MedicineId),
    FOREIGN KEY (DateKey) REFERENCES DimDate(DateKey),
    FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId),
    FOREIGN KEY (MedicineId) REFERENCES DimMedicine(MedicineId)
);
-- MonthlyFact_Perscription
IF OBJECT_ID('dbo.MonthlyFact_Prescription', 'U') IS NOT NULL
    DROP TABLE dbo.MonthlyFact_Prescription;
CREATE TABLE dbo.MonthlyFact_Prescription (
    DateKey DATE NOT NULL,
    DoctorId INT NOT NULL,
    MedicineId INT NOT NULL,
    TotalMonthlyQuantity INT NOT NULL,
    TotalMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    TotalMonthlyNumberOfPatientsPrescribed INT NOT NULL,
    AverageMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MinMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MaxMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    CONSTRAINT PK_MonthlyFact_Prescription PRIMARY KEY (DateKey, DoctorId, MedicineId),
    FOREIGN KEY (DateKey) REFERENCES DimDate(DateKey),
    FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId),
    FOREIGN KEY (MedicineId) REFERENCES DimMedicine(MedicineId)
);
select * from MonthlyFact_Prescription

-- TempFact_ACCPerscription
CREATE TABLE dbo.TempFact_ACCPerscription (
    DoctorId INT NOT NULL,
    MedicineId INT NOT NULL,
    TotalQuantity INT NOT NULL,
    TotalAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    TotalNumberOfPatientsPrescribed INT NOT NULL,
    AverageAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MinAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MaxAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    CONSTRAINT PK_TempFact_ACCPerscription PRIMARY KEY (DoctorId, MedicineId),
    CONSTRAINT FK_TempFact_ACCPerscription_DoctorId FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId),
    CONSTRAINT FK_TempFact_ACCPerscription_MedicineId FOREIGN KEY (MedicineId) REFERENCES DimMedicine(MedicineId)
);

-- ACCFact_Perscription
drop table ACCFact_Prescription
CREATE TABLE dbo.ACCFact_Prescription (
    DoctorId INT NOT NULL,
    MedicineId INT NOT NULL,
    TotalQuantity INT NOT NULL,
    TotalAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    TotalNumberOfPatientsPrescribed INT NOT NULL,
    AverageAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MinAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MaxAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    CONSTRAINT PK_ACCFact_Prescription PRIMARY KEY (DoctorId, MedicineId),
    CONSTRAINT FK_ACCFact_Prescription_DoctorId FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId),
    CONSTRAINT FK_ACCFact_Prescription_MedicineId FOREIGN KEY (MedicineId) REFERENCES DimMedicine(MedicineId)
);
select * from ACCFact_Prescription
-------------------------------------------------------------------------------------------------------------------------------------
												--Treatment Mart--
-------------------------------------------------------------------------------------------------------------------------------------
-- TempFact_TranTreatment
CREATE TABLE TempFact_TranTreatment(
    DateKey DATE,
    TimeKey TIME,
    TreatmentId INT,
    PatientId INT,
    DoctorId INT,
    ConditionId INT,
    TotalAmountDue DECIMAL(18, 2),
    AmountPaidByPatient DECIMAL(18, 2)
);
select * from TempFact_TranTreatment
-- TransacctionFact_Treatment
CREATE TABLE dbo.TranactionFact_Treatment (
    DateKey DATE NOT NULL,
    TimeKey TIME NOT NULL,
    TreatmentId INT NOT NULL,
    PatientId INT NOT NULL,
    DoctorId INT NOT NULL,
    ConditionId INT NOT NULL,
    TotalAmountDue DECIMAL(18, 2) NOT NULL,
    AmountPaidByPatient DECIMAL(18, 2) NOT NULL,
    FOREIGN KEY (DateKey) REFERENCES DimDate(DateKey),
    FOREIGN KEY (TimeKey) REFERENCES DimTime(TimeKey),
    FOREIGN KEY (TreatmentId) REFERENCES DimTreatment(TreatmentId),
    FOREIGN KEY (PatientId) REFERENCES DimPatient(PatientId),
    FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId),
    FOREIGN KEY (ConditionId) REFERENCES DimCondition(ConditionId)
);
select * from TranactionFact_Treatment
select * from [hospital_staging_area].dbo.SA_Treatment
-- TempFact_MonthlyTreatment
CREATE TABLE dbo.TempFact_MonthlyTreatment (
    DateKey DATE NOT NULL,
    TreatmentId INT NOT NULL,
    DoctorId INT NOT NULL,
    TotalMonthlyNumberOfPatientsTreated INT NOT NULL,
    TotalMonthlyAmountDue DECIMAL(18, 2) NOT NULL,
    TotalMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    AverageMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MinMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MaxMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    TotalMonthlyNumberOfDeadPatients INT NOT NULL,
    CONSTRAINT PK_TempFact_MonthlyTreatment PRIMARY KEY (DateKey, TreatmentId, DoctorId),
    CONSTRAINT FK_TempFact_MonthlyTreatment_DateKey FOREIGN KEY (DateKey) REFERENCES DimDate(DateKey),
    CONSTRAINT FK_TempFact_MonthlyTreatment_TreatmentId FOREIGN KEY (TreatmentId) REFERENCES DimTreatment(TreatmentId),
    CONSTRAINT FK_TempFact_MonthlyTreatment_DoctorId FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId)
);
-- MonthlyFact_Treatment
CREATE TABLE dbo.MonthlyFact_Treatment (
    DateKey DATE NOT NULL,
    TreatmentId INT NOT NULL,
    DoctorId INT NOT NULL,
    TotalMonthlyNumberOfPatientsTreated INT NOT NULL,
    TotalMonthlyAmountDue DECIMAL(18, 2) NOT NULL,
    TotalMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    AverageMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MinMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MaxMonthlyAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    TotalMonthlyNumberOfDeadPatients INT NOT NULL,
    CONSTRAINT PK_TMonthlyFact_Treatment PRIMARY KEY (DateKey, TreatmentId, DoctorId),
    CONSTRAINT FK_MonthlyFact_Treatment_DateKey FOREIGN KEY (DateKey) REFERENCES DimDate(DateKey),
    CONSTRAINT FK_MonthlyFact_Treatment_TreatmentId FOREIGN KEY (TreatmentId) REFERENCES DimTreatment(TreatmentId),
    CONSTRAINT FK_MonthlyFact_Treatment_DoctorId FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId)
);
select * from MonthlyFact_Treatment

-- TempFact_ACCTreatment
CREATE TABLE dbo.TempFact_ACCTreatment (
    TreatmentId INT NOT NULL,
    TotalNumberOfPatientsTreated INT NOT NULL,
    TotalAmountDue DECIMAL(18, 2) NOT NULL,
    TotalAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    AverageAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MinAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MaxAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    TotalNumberOfDeadPatients INT NOT NULL,
    CONSTRAINT PK_TempFact_ACCTreatment PRIMARY KEY (TreatmentId),
    CONSTRAINT FK_TempFact_ACCTreatment_TreatmentId FOREIGN KEY (TreatmentId) REFERENCES DimTreatment(TreatmentId)
)
-- ACCFact_Treatment
CREATE TABLE dbo.ACCFact_Treatment (
    TreatmentId INT NOT NULL,
    TotalNumberOfPatientsTreated INT NOT NULL,
    TotalAmountDue DECIMAL(18, 2) NOT NULL,
    TotalAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    AverageAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MinAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    MaxAmountPaidByPatients DECIMAL(18, 2) NOT NULL,
    TotalNumberOfDeadPatients INT NOT NULL,
    CONSTRAINT PK_ACCFact_Treatment PRIMARY KEY (TreatmentId),
    CONSTRAINT FK_ACCFact_Treatment_TreatmentId FOREIGN KEY (TreatmentId) REFERENCES DimTreatment(TreatmentId)
)
select * from ACCFact_Treatment
-------------------------------------------------------------------------------------------------------------------------------------
												--Staff Mart--
-------------------------------------------------------------------------------------------------------------------------------------
-- TempFact_TranStaff
drop table TempFact_TranStaff
CREATE TABLE TempFact_TranStaff (
    DateKey DATE,
    NurseId INT,
    WardId INT,
    StartTime TIME,
    EndTime TIME,
    ShiftTime DECIMAL(5, 2),
    RemainHours DECIMAL(5, 2)
);
select * from TempFact_TranStaff
-- TransactionFact_Staff
CREATE TABLE dbo.TransactionFact_Staff (
    DateKey DATE NOT NULL,
    TimeKey TIME NOT NULL,
    NurseId INT NOT NULL,
    WardId INT NOT NULL,
    StartTimeId TIME NOT NULL,
    EndTimeId TIME NOT NULL,
    ShiftTime DECIMAL(5, 2) NOT NULL,
    RemainHours DECIMAL(5, 2) NOT NULL,
    CONSTRAINT FK_TransactionFact_Staff_DateKey FOREIGN KEY (DateKey) REFERENCES DimDate(DateKey),
    CONSTRAINT FK_TransactionFact_Staff_TimeKey FOREIGN KEY (TimeKey) REFERENCES DimTime(TimeKey),
    CONSTRAINT FK_TransactionFact_Staff_StartTimeId FOREIGN KEY (StartTimeId) REFERENCES DimTime(TimeKey),
    CONSTRAINT FK_TransactionFact_Staff_EndTimeId FOREIGN KEY (EndTimeId) REFERENCES DimTime(TimeKey),
    CONSTRAINT PK_TransactionFact_Staff PRIMARY KEY (DateKey, TimeKey, NurseId, WardId, StartTimeId, EndTimeId)
);
select * from TransactionFact_Staff
-- TempFact_MonthlyStaff

-- MonthlyFact_Staff

-- TempFact_ACCStaff
CREATE TABLE dbo.TempFact_ACCStaff (
    DoctorId INT NOT NULL,
    TreatmentId INT NOT NULL,
    LastTreatmentDate DATE NOT NULL,
    SuccessfullTreatsPercentage DECIMAL(5, 2) NOT NULL,
    AvgCondition DECIMAL(5, 2) NOT NULL,
    TreatmentCount INT NOT NULL,
    GoodConditionCount INT NOT NULL,
    PoorConditionCount INT NOT NULL,
    PatientCount INT NOT NULL,
    LastMonthTreatmentCount INT NOT NULL,
    CONSTRAINT PK_TempFact_ACCStaff PRIMARY KEY (DoctorId, TreatmentId),
    CONSTRAINT FK_TempFact_ACCStaff FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId),
    CONSTRAINT FK_TempFact_ACCStaff_TreatmentId FOREIGN KEY (TreatmentId) REFERENCES DimTreatment(TreatmentId)
);

-- ACCFact_Staff
CREATE TABLE dbo.ACCFact_Staff (
    DoctorId INT NOT NULL,
    TreatmentId INT NOT NULL,
    LastTreatmentDate DATE NOT NULL,
    SuccessfullTreatsPercentage DECIMAL(5, 2) NOT NULL,
    AvgCondition DECIMAL(5, 2) NOT NULL,
    TreatmentCount INT NOT NULL,
    GoodConditionCount INT NOT NULL,
    PoorConditionCount INT NOT NULL,
    PatientCount INT NOT NULL,
    LastMonthTreatmentCount INT NOT NULL,
    CONSTRAINT PK_ACCFact_Staff PRIMARY KEY (DoctorId, TreatmentId),
    CONSTRAINT FK_ACCFact_Staff_DoctorId FOREIGN KEY (DoctorId) REFERENCES DimDoctor(DoctorId),
    CONSTRAINT FK_ACCFact_Staff_TreatmentId FOREIGN KEY (TreatmentId) REFERENCES DimTreatment(TreatmentId)
);
select * from ACCFact_Staff