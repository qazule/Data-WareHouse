-- Sample data for Ward
INSERT INTO Ward (WardId, WardName, Description)
SELECT TOP (50) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), 
       'Ward ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'Description' 
FROM sys.all_objects;

select * from Ward

--------------------------------------------------------------------------
-- Sample data for Room
INSERT INTO Room (RoomId, WardId, RoomNumber)
SELECT TOP (600) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), 
       (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) % 10) + 1, 
       'Room ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR)
FROM sys.all_objects;

select * from Room

--------------------------------------------------------------------------
-- Sample data for InsurancePolicy
INSERT INTO InsurancePolicy (InsuranceNumber, InsuranceNetwork, PolicyName, Description, Deductible, Co_pay)
SELECT TOP (1000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), 
       'Network ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'Policy ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'Description', 
       100 + ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), 
       20 
FROM sys.all_objects;

select * from InsurancePolicy

--------------------------------------------------------------------------
-- Sample data for Patient
INSERT INTO Patient (PatientId, RoomId, FirstName, LastName, Gender, BirthDate, Email, Phone, StreetAdress, City, State, Zipcode, Allergies, ChronicDisease, OtherHealthConcerns, InsuranceNumber)
SELECT TOP (1000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), 
       (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) % 100) + 1, 
       'First' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'Last' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'M', 
       '1990-01-01', 
       'email' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR) + '@example.com', 
       '123-456-' + RIGHT('0000' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 4), 
       'Street Address', 'City', 'State', 'Zipcode', 
       'Allergies', 'Chronic Disease', 'Other Concerns', 
       (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) % 1000) + 1 
FROM sys.all_objects;

select * from Patient

--------------------------------------------------------------------------
-- Clear existing data in Speciality table
DELETE FROM Speciality;

-- Insert data into Speciality table
INSERT INTO Speciality (SpecialityId, SpecialityName, Description)
SELECT TOP (10) 
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)),
    'Speciality ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR),
    'Description ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR)
FROM sys.all_objects;

select * from Speciality

--------------------------------------------------------------------------
DELETE Supervisor
-- Insert data into Supervisor table
INSERT INTO Supervisor (SupervisorId, FirstName, LastName, Gender, BirthDate, Email, Phone, StreetAdress, City, State)
SELECT TOP (10)
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)),
    'SupervisorFirst' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR),
    'SupervisorLast' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR),
    CASE WHEN ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) % 2 = 0 THEN 'M' ELSE 'F' END,
    DATEADD(YEAR, -50, GETDATE()),  -- Random birth date approximately 50 years ago
    'supervisor' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR) + '@example.com',
    '987-654-' + RIGHT('0000' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 4),
    'Supervisor Street Address',
    'Supervisor City',
    'Supervisor State'
FROM sys.all_objects;

select * from Supervisor

--------------------------------------------------------------------------
-- Delete existing records from Doctor table
DELETE FROM Doctor;

-- Insert sample data into Doctor table
INSERT INTO Doctor (DoctorId, SpecialityId, FirstName, LastName, Gender, BirthDate, Email, Phone, StreetAdress, City, State, SupervisorId)
SELECT TOP (100)
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS DoctorId,
    (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) % 10) + 1 AS SpecialityId, -- Assign random SpecialityId from 1 to 10
    'DoctorFirst' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR) AS FirstName,
    'DoctorLast' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR) AS LastName,
    CASE WHEN ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) % 2 = 0 THEN 'M' ELSE 'F' END AS Gender,
    DATEADD(YEAR, -40, GETDATE()) AS BirthDate, -- Use the current date as the base
    'docemail' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR) + '@example.com' AS Email,
    '987-654-' + RIGHT('0000' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 4) AS Phone,
    'Doc Street Address' AS StreetAdress,
    'Doc City' AS City,
    'Doc State' AS State,
    (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) % 10) + 1 AS SupervisorId -- Assign random SupervisorId from 1 to 10
FROM sys.all_objects;

select * from Doctor

--------------------------------------------------------------------------
DELETE FROM TreatmentDetails;

INSERT INTO TreatmentDetails (TreatmentDetailsId, TreatmentName, Description, Price)
SELECT TOP (50) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), 
       'Treatment ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'Description', 
       100 + ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) 
FROM sys.all_objects;

select * from TreatmentDetails

--------------------------------------------------------------------------
INSERT INTO Medicine (MedicineId, medicineName, Description, SideEffects, expiryDate, Form, Dosage, ManufacturerName, Price)
SELECT TOP (1000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), 
       'Medicine ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'Description', 
       'SideEffects', 
       '2025-01-01', 
       'Form', 
       'Dosage', 
       'Manufacturer', 
       20 + ROW_NUMBER() OVER (ORDER BY (SELECT NULL))
FROM sys.all_objects;

SELECT * FROM Medicine

--------------------------------------------------------------------------
INSERT INTO Pharmacy (PharmacyId, StoreNName, StreetAddress, City, State, Zipcode, Phone, LeadPharmacist, Email)
SELECT TOP (50) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), 
       'Store ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'Street Address', 'City', 'State', 'Zipcode', 
       '123-456-' + RIGHT('0000' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 4), 
       'Pharmacist ' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR), 
       'pharmaemail' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS VARCHAR) + '@example.com'
FROM sys.all_objects;

select * from Pharmacy

--------------------------------------------------------------------------
DECLARE @i INT = 1;
WHILE @i <= 1000000
BEGIN
    INSERT INTO Treatment (TreatmentId, PatientId, DoctorId, TreatmentDetailsId, CurrentCondition, TreatmentDate)
    VALUES (
        @i,
        (@i % 1000) + 1,  -- Random PatientId
        (@i % 100) + 1,   -- Random DoctorId
        (@i % 50) + 1,    -- Random TreatmentDetailsId
        'Condition ' + CAST(@i AS VARCHAR),
        DATEADD(DAY, -(@i % 365), GETDATE())  -- Random TreatmentDate within the last year
    );

    SET @i = @i + 1;
END;

select * from Treatment

--------------------------------------------------------------------------
DECLARE @j INT = 1;
WHILE @j <= 1000000
BEGIN
    INSERT INTO Perscription (PerscriptionId, MedicineId, DoctorId, Quantity, AmountPaidByPatient)
    VALUES (
        @j,
        (@j % 1000) + 1,  -- Random MedicineId
        (@j % 100) + 1,   -- Random DoctorId
        (@j % 10) + 1,    -- Random Quantity (assuming a range from 1 to 10)
        (@j % 200)        -- Random AmountPaidByPatient (assuming a range from 0 to 199)
    );

    SET @j = @j + 1;
END;

select * from Perscription

--------------------------------------------------------------------------
delete PerscriptionHistory

DECLARE @k INT = 1;
WHILE @k <= 1000000
BEGIN
    INSERT INTO PerscriptionHistory (PatientId, PharmacyId, PerscriptionId, DatePerscribed, UsageInstruction)
    VALUES (
        (@k % 1000) + 1,  -- Random PatientId
        (@k % 50) + 1,    -- Random PharmacyId
        @k,               -- Use the same @j as PrescriptionId to maintain consistency
        DATEADD(DAY, -(@k % 365), GETDATE()),  -- Random DatePrescribed within the last year
        'Usage Instruction ' + CAST(@k AS VARCHAR)  -- Example UsageInstruction
    );

    SET @k = @k + 1;
END;

SELECT * FROM PerscriptionHistory