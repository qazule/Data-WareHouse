-------------------------------------------------------------------------------------------------------------------------------------
												--Perscription Mart--
-------------------------------------------------------------------------------------------------------------------------------------
-- [TempFact_TranPerscription]
SELECT 
    CONVERT(DATE, PH.DatePerscribed) AS DateKey,
    CONVERT(TIME, PH.DatePerscribed) AS TimeKey,
    PH.PatientId,
    P.DoctorId,
    PH.PharmacyId,
    P.MedicineId,
    P.AmountPaidByPatient,
    P.Quantity
FROM [hospital_staging_area].[dbo].SA_PerscriptionHistory PH
JOIN [hospital_staging_area].[dbo].SA_Perscription P ON PH.PerscriptionId = P.PerscriptionId;
-- TransactionFact_Perscription
SELECT 
    d.DateKey as DateKey,
    t.TimeKey as TimeKey,
    dp.PatientId as PatientId,
    dd.DoctorId as DoctorId,
    ph.PharmacyId as PharmacyId,
    dm.MedicineId as MedicineId,
    tmp.AmountPaidByPatient as AmountPaidByPatient,
    tmp.Quantity as Quantity
FROM 
    dbo.[TempFact_TranPerscription] tmp
JOIN 
	DimDate d ON tmp.DateKey = d.DateKey
JOIN 
    DimTime t ON 
        DATEPART(HOUR, tmp.TimeKey) = t.Hour AND
        DATEPART(MINUTE, tmp.TimeKey) = t.Minute AND
        DATEPART(SECOND, tmp.TimeKey) = t.Second
JOIN 
    DimPatient dp ON tmp.PatientId = dp.PatientCode
JOIN 
    DimDoctor dd ON tmp.DoctorId = dd.DoctorId
JOIN 
    DimPharmacy ph ON tmp.PharmacyId = ph.PharmacyId
JOIN 
    DimMedicine dm ON tmp.MedicineId = dm.MedicineId;

SELECT 
    COLUMN_NAME, DATA_TYPE 
FROM 
    INFORMATION_SCHEMA.COLUMNS 
WHERE 
    TABLE_NAME = 'TransactionFact_Prescription' 
    AND COLUMN_NAME = 'DateKey';

-- TempFact_MonthlyPerscription
SELECT
    EOMONTH(tfp.DateKey) AS DateKey,
    tfp.DoctorId,
    tfp.MedicineId,
    SUM(tfp.Quantity) AS TotalMonthlyQuantity,
    SUM(tfp.AmountPaidByPatient) AS TotalMonthlyAmountPaidByPatients,
    COUNT(DISTINCT tfp.PatientId) AS TotalMonthlyNumberOfPatientsPrescribed,
    AVG(tfp.AmountPaidByPatient) AS AverageMonthlyAmountPaidByPatients,
    MIN(tfp.AmountPaidByPatient) AS MinMonthlyAmountPaidByPatients,
    MAX(tfp.AmountPaidByPatient) AS MaxMonthlyAmountPaidByPatients
FROM
    dbo.TransactionFact_Prescription tfp
JOIN
    dbo.DimDate dd ON EOMONTH(tfp.DateKey) = dd.DateKey
GROUP BY
    EOMONTH(tfp.DateKey),
    tfp.DoctorId,
    tfp.MedicineId;
select * from TempFact_MonthlyPerscription
-- MonthlyFact_Perscription
SELECT
    d.DateKey,
    dd.DoctorId,
    dm.MedicineId,
    tmp.TotalMonthlyQuantity,
    tmp.TotalMonthlyAmountPaidByPatients,
    tmp.TotalMonthlyNumberOfPatientsPrescribed,
    tmp.AverageMonthlyAmountPaidByPatients,
    tmp.MinMonthlyAmountPaidByPatients,
    tmp.MaxMonthlyAmountPaidByPatients
FROM
    dbo.TempFact_MonthlyPerscription tmp
JOIN
    dbo.DimDate d ON tmp.DateKey = d.DateKey
JOIN
    dbo.DimDoctor dd ON tmp.DoctorId = dd.DoctorId
JOIN
    dbo.DimMedicine dm ON tmp.MedicineId = dm.MedicineId;

-- TempFact_ACCPerscription
SELECT
    m.DoctorId,
    m.MedicineId,
    SUM(m.TotalMonthlyQuantity) AS TotalQuantity,
    SUM(m.TotalMonthlyAmountPaidByPatients) AS TotalAmountPaidByPatients,
    COUNT(m.TotalMonthlyNumberOfPatientsPrescribed) AS TotalNumberOfPatientsPrescribed,
    AVG(m.AverageMonthlyAmountPaidByPatients) AS AverageAmountPaidByPatients,
    MIN(m.MinMonthlyAmountPaidByPatients) AS MinAmountPaidByPatients,
    MAX(m.MaxMonthlyAmountPaidByPatients) AS MaxAmountPaidByPatients
FROM
    dbo.MonthlyFact_Prescription m
JOIN 
    dbo.DimDoctor dd ON m.DoctorId = dd.DoctorId
JOIN
	dbo.DimMedicine dm ON m.MedicineId = dm.MedicineId
GROUP BY
    m.DoctorId,
    m.MedicineId;
select * from 
-- ACCFact_Perscription
SELECT
    dd.DoctorId,
    dm.MedicineId,
    tmp.TotalQuantity,
    tmp.TotalAmountPaidByPatients,
    tmp.TotalNumberOfPatientsPrescribed,
    tmp.AverageAmountPaidByPatients,
    tmp.MinAmountPaidByPatients,
    tmp.MaxAmountPaidByPatients
FROM
    dbo.TempFact_ACCPerscription tmp
JOIN
    dbo.DimDoctor dd ON tmp.DoctorId = dd.DoctorId
JOIN
    dbo.DimMedicine dm ON tmp.MedicineId = dm.MedicineId;
-------------------------------------------------------------------------------------------------------------------------------------
												--Treatment Mart--
-------------------------------------------------------------------------------------------------------------------------------------
-- TempFact_TranTreatment
SELECT 
    t.TreatmentDate AS DateKey,
    CAST(t.TreatmentDate AS TIME) AS TimeKey,
    td.TreatmentDetailsId AS TreatmentId,
    t.PatientId,
    t.DoctorId,
    dc.ConditionId,
    p.TotalAmountDue,
    p.AmountPaid as AmountPaidByPatient
FROM 
    [hospital_staging_area].[dbo].SA_Treatment t
JOIN 
	[hospital_staging_area].[dbo].SA_TreatmentDetails td ON td.TreatmentDetailsId = t.TreatmentDetailsId
JOIN
    [hospital_staging_area].[dbo].SA_Payment p ON t.TreatmentId = p.TreatmentId
JOIN 
    (SELECT DISTINCT 
         CurrentCondition, 
         CASE 
             WHEN CurrentCondition = 'good' THEN 1
             WHEN CurrentCondition = 'fair' THEN 2
             WHEN CurrentCondition = 'poor' THEN 3
             WHEN CurrentCondition = 'dead' THEN 4
             ELSE NULL  -- Handle unexpected values
         END AS ConditionId
     FROM [hospital_staging_area].[dbo].SA_Treatment) dc ON t.CurrentCondition = dc.CurrentCondition;
-- TransactionFact_Treatment
SELECT 
    d.DateKey,
    t.TimeKey,
    tmp.TreatmentId,
    dp.PatientId,
    dd.DoctorId,
    dc.ConditionId,
    tmp.TotalAmountDue,
    tmp.AmountPaidByPatient
FROM 
    dbo.TempFact_TranTreatment tmp
JOIN 
    DimDate d ON tmp.DateKey = d.DateKey
JOIN 
    DimTime t ON 
        DATEPART(HOUR, tmp.TimeKey) = t.Hour AND
        DATEPART(MINUTE, tmp.TimeKey) = t.Minute AND
        DATEPART(SECOND, tmp.TimeKey) = t.Second
JOIN 
    DimPatient dp ON tmp.PatientId = dp.PatientCode
JOIN 
    DimDoctor dd ON tmp.DoctorId = dd.DoctorId
JOIN 
    DimCondition dc ON tmp.ConditionId = dc.ConditionId;

-- TempFact_MonthlyTreatment
SELECT
    EOMONTH(tft.DateKey) AS DateKey,
    tft.TreatmentId,
    tft.DoctorId,
    COUNT(DISTINCT tft.PatientId) AS TotalMonthlyNumberOfPatientsTreated,
    SUM(tft.TotalAmountDue) AS TotalMonthlyAmountDue,
    SUM(tft.AmountPaidByPatient) AS TotalMonthlyAmountPaidByPatients,
    AVG(tft.AmountPaidByPatient) AS AverageMonthlyAmountPaidByPatients,
    MIN(tft.AmountPaidByPatient) AS MinMonthlyAmountPaidByPatients,
    MAX(tft.AmountPaidByPatient) AS MaxMonthlyAmountPaidByPatients,
    COUNT(CASE WHEN dc.ConditionVal = 0 THEN 1 ELSE NULL END) AS TotalMonthlyNumberOfDeadPatients
FROM
    dbo.TransactionFact_Treatment tft
JOIN 
    dbo.DimPatient dp ON tft.PatientId = dp.PatientId
JOIN
	dbo.DimCondition dc ON tft.ConditionId = dc.ConditionId
GROUP BY
    EOMONTH(tft.DateKey),
    tft.TreatmentId,
    tft.DoctorId;
select * from TempFact_MonthlyTreatment
-- MonthlyFact_Treatment
SELECT
    d.DateKey,
    doc.DoctorId,
    t.TreatmentId,
    tmp.TotalMonthlyNumberOfPatientsTreated,
    tmp.TotalMonthlyAmountDue,
    tmp.TotalMonthlyAmountPaidByPatients,
    tmp.AverageMonthlyAmountPaidByPatients,
    tmp.MinMonthlyAmountPaidByPatients,
    tmp.MaxMonthlyAmountPaidByPatients,
	tmp.TotalMonthlyNumberOfDeadPatients
FROM
    dbo.TempFact_MonthlyTreatment tmp
JOIN
    DimDate d ON tmp.DateKey = d.DateKey
JOIN
    DimTreatment t ON tmp.TreatmentId = t.TreatmentId
JOIN
    DimDoctor doc ON tmp.DoctorId = doc.DoctorId

-- TempFact_ACCTreatment
SELECT
    m.TreatmentId,
    SUM(m.TotalMonthlyNumberOfPatientsTreated) AS TotalNumberOfPatientsTreated,
    SUM(m.TotalMonthlyAmountDue) AS TotalAmountDue,
    SUM(m.TotalMonthlyAmountPaidByPatients) AS TotalAmountPaidByPatients,
    AVG(m.AverageMonthlyAmountPaidByPatients) AS AverageAmountPaidByPatients,
    MIN(m.MinMonthlyAmountPaidByPatients) AS MinAmountPaidByPatients,
    MAX(m.MaxMonthlyAmountPaidByPatients) AS MaxAmountPaidByPatients,
    SUM(m.TotalMonthlyNumberOfDeadPatients) AS TotalNumberOfDeadPatients
FROM
    dbo.MonthlyFact_Treatment m
GROUP BY
    m.TreatmentId;
-- ACCFact_Treattment
SELECT
    dt.TreatmentId,
    tf.TotalNumberOfPatientsTreated,
    tf.TotalAmountDue,
    tf.TotalAmountPaidByPatients,
    tf.AverageAmountPaidByPatients,
    tf.MinAmountPaidByPatients,
    tf.MaxAmountPaidByPatients,
    tf.TotalNumberOfDeadPatients
FROM
    dbo.TempFact_ACCTreatment tf
JOIN
    dbo.DimTreatment dt ON tf.TreatmentId = dt.TreatmentId;
-------------------------------------------------------------------------------------------------------------------------------------
												--Staff Mart--
-------------------------------------------------------------------------------------------------------------------------------------
-- TempFact_TranStaff
-- first load
SELECT 
    CONVERT(DATE, Shift_end_time) AS DateKey, 
    NurseId, 
    WardId, 
    CONVERT(TIME, Shift_start_time) AS StartTime, 
    CONVERT(TIME, Shift_end_time) AS EndTime,
    CONVERT(DECIMAL(5, 2), ABS(DATEDIFF(HOUR, Shift_start_time, Shift_end_time))) AS ShiftTime
FROM 
    [hospital_staging_area].[dbo].SA_NurseWard;
UPDATE tts
SET tts.RemainHours =CASE WHen dn.DueWorkHoursPerMonth - agg.TotalShiftTime < 0 then 0
						else dn.DueWorkHoursPerMonth - agg.TotalShiftTime
						end
FROM dbo.TempFact_TranStaff tts
JOIN DimNurse dn ON tts.NurseId = dn.NurseId
JOIN (
    SELECT
        NurseId,
        YEAR(DateKey) AS Year,
        MONTH(DateKey) AS Month,
        SUM(ShiftTime) AS TotalShiftTime
    FROM dbo.TempFact_TranStaff
    GROUP BY NurseId, YEAR(DateKey), MONTH(DateKey)
) agg ON tts.NurseId = agg.NurseId AND YEAR(tts.DateKey) = agg.Year AND MONTH(tts.DateKey) = agg.Month;
select * from [hospital_staging_area].[dbo].SA_NurseWard
-- update

INSERT INTO dbo.Nurse_Attendance_Transactional (DateKey, TimeKey, NurseId, WardId, Start_TimeId, End_TimeId)
SELECT nw.DateKey, nw.TimeKey, nw.NurseId, nw.WardId, nw.Start_TimeId, nw.End_TimeId
FROM NurseWard nw
LEFT JOIN dbo.Nurse_Attendance_Transactional nat ON nw.DateKey = nat.DateKey AND nw.TimeKey = nat.TimeKey AND nw.NurseId = nat.NurseId AND nw.WardId = nat.WardId AND nw.Start_TimeId = nat.Start_TimeId AND nw.End_TimeId = nat.End_TimeId
WHERE nat.NurseId IS NULL;

UPDATE nat
SET nat.Remain_Hours = dn.DueWorksPerMonth - agg.TotalShiftTime
FROM dbo.Nurse_Attendance_Transactional nat
JOIN DimNurse dn ON nat.NurseId = dn.NurseId
JOIN (
    SELECT
        NurseId,
        YEAR(DateKey) AS Year,
        MONTH(DateKey) AS Month,
        SUM(DATEDIFF(HOUR, Start_TimeId, End_TimeId)) AS TotalShiftTime
    FROM dbo.Nurse_Attendance_Transactional
    WHERE DateKey >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) -- focusing on the current month only
    GROUP BY NurseId, YEAR(DateKey), MONTH(DateKey)
) agg ON nat.NurseId = agg.NurseId AND YEAR(nat.DateKey) = agg.Year AND MONTH(nat.DateKey) = agg.Month;



-- TransactionFact_Staff
SELECT
    dd.DateKey,
    tfts.StartTime AS TimeKey,  -- Assuming StartTime as TimeKey for simplicity
    tfts.NurseId,
    tfts.WardId,
    tfts.StartTime AS StartTimeId,
    tfts.EndTime AS EndTimeId,
    tfts.ShiftTime,
    tfts.RemainHours
FROM
    dbo.TempFact_TranStaff tfts
JOIN
    dbo.DimDate dd ON tfts.DateKey = dd.DateKey



-- MonthlyFact_Staff
-- first load
INSERT INTO dbo.Monthly_Nurse_Fact (DateKey, NurseId, WardId, Hours_Worked, Overtime_Hours, Absence_Count, Undertime_Hours, Avg_Work_Hour)
SELECT
    DATEADD(MONTH, DATEDIFF(MONTH, 0, nat.DateKey), 0) AS MonthStart,
    nat.NurseId,
    nat.WardId,
    SUM(nat.Shift_Time) AS Hours_Worked,
    CASE 
        WHEN SUM(nat.Shift_Time) - dn.DueWorksPerMonth > 0 THEN SUM(nat.Shift_Time) - dn.DueWorksPerMonth
        ELSE 0
    END AS Overtime_Hours,
    -- Assuming there's a way to calculate absence, potentially by counting the gaps in DateKey or similar
    -- You will need to adjust this based on your data model and assumptions
    (SELECT COUNT(DISTINCT DateKey) FROM DimDate WHERE MONTH(DateKey) = MONTH(nat.DateKey) AND YEAR(DateKey) = YEAR(nat.DateKey)
     AND DateKey NOT IN (SELECT DISTINCT DateKey FROM Nurse_Attendance_Transactional WHERE NurseId = nat.NurseId AND WardId = nat.WardId)) AS Absence_Count,
    dn.DueWorksPerMonth - SUM(nat.Shift_Time) AS Undertime_Hours,
    AVG(nat.Shift_Time) AS Avg_Work_Hour
FROM
    dbo.Nurse_Attendance_Transactional nat
JOIN
    DimNurse dn ON nat.NurseId = dn.NurseId
GROUP BY
    nat.NurseId,
    nat.WardId,
    YEAR(nat.DateKey),
    MONTH(nat.DateKey),
    dn.DueWorksPerMonth;

-- update
-- Assume updates are run monthly and focus on the current month
DECLARE @CurrentMonthStart DATE = DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0);

-- Delete existing records for the current month to recompute them
DELETE FROM dbo.Monthly_Nurse_Fact
WHERE DateKey = @CurrentMonthStart;

-- Insert updated aggregates for the current month
INSERT INTO dbo.Monthly_Nurse_Fact (DateKey, NurseId, WardId, Hours_Worked, Overtime_Hours, Absence_Count, Undertime_Hours, Avg_Work_Hour)
SELECT
    @CurrentMonthStart AS MonthStart,
    nat.NurseId,
    nat.WardId,
    SUM(nat.Shift_Time) AS Hours_Worked,
    CASE 
        WHEN SUM(nat.Shift_Time) - dn.DueWorksPerMonth > 0 THEN SUM(nat.Shift_Time) - dn.DueWorksPerMonth
        ELSE 0
    END AS Overtime_Hours,
    (SELECT COUNT(DISTINCT DateKey) FROM DimDate
     WHERE MONTH(DateKey) = MONTH(@CurrentMonthStart) AND YEAR(DateKey) = YEAR(@CurrentMonthStart)
     AND DateKey NOT IN (SELECT DISTINCT DateKey FROM Nurse_Attendance_Transactional
                         WHERE NurseId = nat.NurseId AND WardId = nat.WardId AND MONTH(DateKey) = MONTH(@CurrentMonthStart) AND YEAR(DateKey) = YEAR(@CurrentMonthStart))) AS Absence_Count,
    dn.DueWorksPerMonth - SUM(nat.Shift_Time) AS Undertime_Hours,
    AVG(nat.Shift_Time) AS Avg_Work_Hour
FROM
    dbo.Nurse_Attendance_Transactional nat
JOIN
    DimNurse dn ON nat.NurseId = dn.NurseId
WHERE
    MONTH(nat.DateKey) = MONTH(@CurrentMonthStart) AND YEAR(nat.DateKey) = YEAR(@CurrentMonthStart)
GROUP BY
    nat.NurseId,
    nat.WardId,
    dn.DueWorksPerMonth;


-- TempFact_ACCStaff
SELECT
    f.DoctorId,
    f.TreatmentId,
    MAX(f.DateKey) AS LastTreatmentDate,
    ROUND(
        100.0 * SUM(CASE WHEN c.ConditionDesc = 'good' THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) AS SuccessfullTreatsPercentage,
    SUM(CASE WHEN c.ConditionDesc = 'good' THEN 1 ELSE 0 END) AS GoodConditionCount,
    SUM(CASE WHEN c.ConditionDesc = 'poor' THEN 1 ELSE 0 END) AS PoorConditionCount,
    COUNT(DISTINCT f.PatientId) AS PatientCount,
    SUM(CASE WHEN f.DateKey >= DATEADD(MONTH, -1, GETDATE()) THEN 1 ELSE 0 END) AS LastMonthTreatmentCount,
    AVG(TRY_CAST(c.ConditionVal AS DECIMAL(18, 2))) AS AvgCondition,
	COUNT(*) AS TreatmentCount
FROM
    dbo.TranactionFact_Treatment f
JOIN
    DimCondition c ON f.ConditionId = c.ConditionId
GROUP BY
    f.DoctorId,
    f.TreatmentId;

-- ACCFact_Staff
-- first load
SELECT
    d.DoctorId,
    tr.TreatmentId,
    t.LastTreatmentDate,
    t.SuccessfullTreatsPercentage,
    t.AvgCondition,
    t.TreatmentCount,
    t.GoodConditionCount,
    t.PoorConditionCount,
    t.PatientCount,
    t.LastMonthTreatmentCount
FROM
    dbo.TempFact_ACCStaff t
JOIN
    DimDoctor d ON t.DoctorId = d.DoctorId
JOIN
    DimTreatment tr ON t.TreatmentId = tr.TreatmentId;

-- update
INSERT INTO dbo.Nurse_Attendance_Transactional (DateKey, TimeKey, NurseId, WardId, Start_TimeId, End_TimeId)
SELECT nw.DateKey, nw.TimeKey, nw.NurseId, nw.WardId, nw.Start_TimeId, nw.End_TimeId
FROM NurseWard nw
LEFT JOIN dbo.Nurse_Attendance_Transactional nat ON nw.DateKey = nat.DateKey AND nw.TimeKey = nat.TimeKey AND nw.NurseId = nat.NurseId AND nw.WardId = nat.WardId AND nw.Start_TimeId = nat.Start_TimeId AND nw.End_TimeId = nat.End_TimeId
WHERE nat.NurseId IS NULL;


UPDATE nat
SET nat.Remain_Hours = dn.DueWorksPerMonth - agg.TotalShiftTime
FROM dbo.Nurse_Attendance_Transactional nat
JOIN DimNurse dn ON nat.NurseId = dn.NurseId
JOIN (
    SELECT
        NurseId,
        YEAR(DateKey) AS Year,
        MONTH(DateKey) AS Month,
        SUM(DATEDIFF(HOUR, Start_TimeId, End_TimeId)) AS TotalShiftTime
    FROM dbo.Nurse_Attendance_Transactional
    WHERE DateKey >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) -- focusing on the current month only
    GROUP BY NurseId, YEAR(DateKey), MONTH(DateKey)
) agg ON nat.NurseId = agg.NurseId AND YEAR(nat.DateKey) = agg.Year AND MONTH(nat.DateKey) = agg.Month;

